//
//  CreatePlcsModel.swift
//  MyPlan
//
//  Created by Mac on 04/09/2022.
//

import Foundation

struct CreatePlcsModel: Identifiable{
    
    let id = UUID()
    
    var PlName : String
    
}

