//
//  MyPlanApp.swift
//  MyPlan
//
//  Created by Mac on 27/08/2022.
//

import SwiftUI

@main
struct MyPlanApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
            
        }
    }
}
